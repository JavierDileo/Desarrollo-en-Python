# Imprimir los números entre el 5 y el 20, saltando de tres en tres.

print("--------------SALTANDO DE 3 EN 3------------------")

#IMPRESION CADA 3 VUELTAS DE LOS NUMEROS ENTRE 5 Y 20
for i in range(5,21,3):
    print(i,end=" - ")
print("\n--------------------------------------------------")