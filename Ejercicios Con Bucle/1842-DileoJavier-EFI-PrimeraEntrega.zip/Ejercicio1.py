# Imprimir todos los dígitos decimales, del 0 al 9, utilizando una repeticion.


print("-------IMPRESION DE LOS NUMEROS DEL 0 AL 9--------")

#IMPRESION POR PANTALLA DE LOS NUMEROS DEL 0 AL 9
for i in range(10):
    print(i, end=" - ")

print("\n--------------------------------------------------")