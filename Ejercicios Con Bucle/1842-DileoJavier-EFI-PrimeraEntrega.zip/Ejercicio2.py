# Imprimir todos los números entre el 100 y el 199.


print("--------------------------------------------IMPRESION DE LOS NUMEROS DEL 100 AL 199---------------------------------------------")
#IMPRESION POR PANTALLA DESDE EL NUMERO 100 HASTA EL 199
for i in range(100 ,200):
    print(i,end = " - ")

print("\n--------------------------------------------------------------------------------------------------------------------------------")